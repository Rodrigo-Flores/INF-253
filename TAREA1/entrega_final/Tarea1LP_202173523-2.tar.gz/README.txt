Nombre: Rodrigo Ignacio Flores Figueroa
ROL: 202173523-2
Version: Python 3.10.4

Intrucciones de ejecución:
    - Ejecutar en terminar: python pixelart.py o python3 pixelart.py
    - El nombre del archivo a leer es por defecto "texto.txt"; se puede cambiar en el código.


Detalles de funcionamiento:
    - El programa logra reconocer y ejecutar instrucciones como Pintar, Avanzar, Derecha, Izquierda, Ancho, Color de fondo y los respectivos colores.
    - Se puede cambiar la ruta de exportacion de la imagen cuando se llama al metodo de exportar.
    - El programa lee algunos errores básicos en la sintaxis.